import React, { useState, useEffect } from 'react';
import { Text, View, StyleSheet, FlatList } from 'react-native';

import {
        TouchableOpacity,
        } from 'react-native';
        

export default class Filter extends React.PureComponent { 
  
   constructor(props){
    super(props);
    this.state = {imovel: this.props.imovel};
   }
 render() {
   const {imovel}=this.state;
   return (
       <TouchableOpacity> 
     <Text style={styles.filterText}> Imóvel a Venda</Text>
       </TouchableOpacity>
           
   );
 }

  const [text, setText] = useState('')
  const [list, setList] = useState('')
  const [items, setItems] = useState('')


  useEffect(()=>{
    setList(imovel.address.formattedAddress) // mostra a lista de endereço na tela
    setItems(imovel.address.formattedAddress)    
  },[]) 

  function SearchFilterFunction(text) {
            
    const filterList = items.filter((item) => {
            
      const itemFilter = item.name ? item.name.toUpperCase() : ''.toUpperCase();
      const newText = text.toUpperCase();
      return itemFilter.indexOf(newText) > -1;
    });
          
    setList(filterList)
    setText(text)
  }
  return(
    <View style={styles.container}>
        <Header searchBar rounded style={{backgroundColor:'#fff', marginTop:10}}>
          <Item>
            <Icon name="ios-search" />

            <Input placeholder="Search" onChangeText={(t)=>SearchFilterFunction(t)} value={text}/>
          
          </Item>
          <Button transparent>
            <Text>Search</Text>
          </Button>
        </Header>

        <FlatList style={styles.address}
                data={list}
                renderItem={({item})=><ItemList data={item}/>}
                enableEmptySections={true}
        />


    </View>
  )

}         
const styles = StyleSheet.create({

  filterText: {
  padding:1,
  fontSize:16
  },
});
